﻿using System;
using System.Collections.Generic;

namespace Bar {
    class Program {
        static void Main (string[] args) {
            string controle;
            Pedido lista = new Pedido();

            do
            {
                ItemPedido item = new ItemPedido();
                Console.WriteLine ("Entre descrição:");
                item.descricao = Console.ReadLine ();
                Console.WriteLine ("Entre valor:");
                item.valor_unitario = Double.Parse (Console.ReadLine ());
                Console.WriteLine ("Entre quantidade:");
                item.quantidade = int.Parse (Console.ReadLine ());
    
                lista.IncluirItem(item);
                Console.WriteLine ("Deseja inserir mais um pedido? sim ou nao");
                controle = Console.ReadLine();

            }while (controle.ToLower() == "sim");
            Console.WriteLine("O total da conta é R$" + lista.TotalizarPedido());
        }
    }
}